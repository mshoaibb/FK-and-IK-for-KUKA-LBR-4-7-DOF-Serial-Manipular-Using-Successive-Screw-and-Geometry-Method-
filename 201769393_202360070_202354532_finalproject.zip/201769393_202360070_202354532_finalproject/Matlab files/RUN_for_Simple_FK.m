%% Group Members

% Mohammad Shoaib Babar
% Azat Balapan
% Ihteshamul Hayat

%% Forward Kinematics
% KUKA LBR 4+ robot

clear all
close all
clc

syms t1 t2 t3 t4 t5 t6 t7 
syms d0 d1 d2 d3 d4 d5 d6 
syms k1 k2 k3 k4 k5 k6 k7
syms R3 R4 R5 R6 RH

%Let

% k1= d0; 
% k2= d0+d1;
% k3= d0+d1+d2;
% k4= d0+d1+d2+d3;
% k5= d0+d1+d2+d3+d4;
% k6= d0+d1+d2+d3+d4+d5;
% k7= d0+d1+d2+d3+d4+d5+d6;
% 
% % Angle in for each joint
% % for Kuka LWR R+
% 
% t1 = -pi/2; 
% t2 =  pi/2; 
% t3 = -pi/2;
% t4 =  pi/2; 
% t5 = -pi/2; 
% t6 =  pi/2;
% t7 =  0;
% 
% k1= 0.1105;
% k2= 0.31048-0.1105;
% k3= 0.5105-0.31048;
% k4= 0.7105-0.5105;
% k5= 0.9105-0.7105;
% k6= 1.1005-0.9105;
% k7= 1.1785-1.1005;
%-----------------
 
A = [cos(t1), -sin(t1), 0, 0;
sin(t1),  cos(t1), 0, 0;
          0,            0, 1, 0;
          0,            0, 0, 1]
 
 
B =[cos(t2), 0, -sin(t2),        sin(t2)*(k2);
          0, 1,            0,                              0;
sin(t2), 0,  cos(t2), -(d0 + d1)*(cos(t2) - 1);
          0, 0,            0,                              1]
 
 
C =[cos(t3), -sin(t3), 0, 0;
sin(t3),  cos(t3), 0, 0;
          0,            0, 1, 0;
          0,            0, 0, 1]
 
 
D =[cos(t4), 0, -sin(t4),        sin(t4)*(k3);
          0, 1,            0,                                          0;
sin(t4), 0,  cos(t4), -(cos(t4) - 1)*(k3);
          0, 0,            0,                                          1]
 
 
E = [cos(t5), -sin(t5), 0, 0;
sin(t5),  cos(t5), 0, 0;
          0,            0, 1, 0;
          0,            0, 0, 1]
 
 
F =[cos(t6), 0, -sin(t6),        sin(t6)*(k6);
          0, 1,            0,                                                      0;
sin(t6), 0,  cos(t6), -(cos(t6) - 1)*(k6);
          0, 0,            0,                                                      1]
 
 
G = [cos(t7), -sin(t7), 0, 0;
sin(t7),  cos(t7), 0, 0;
          0,            0, 1, 0;
          0,            0, 0, 1]

P = [1, 0, 0, 0;
     0, 1, 0, 0;
     0, 0, 1, k7;
     0, 0, 0, 1 ]

% This will give us solution
% for 0 - 7 transformation matrics            
Ah = A*B*C*D*E*F*G;

% This will multiply 
% Ah and P matrics


R4 = tform2rotm(E)
R5 = tform2rotm(F)
R6 = tform2rotm(G)

RH=R4*R5*R6

FK = Ah * P;
simplify (FK);



%---------

