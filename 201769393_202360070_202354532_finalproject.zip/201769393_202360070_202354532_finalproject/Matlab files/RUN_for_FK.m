clear all; close all; clc
%2nd file
%code to find matrics
% need to write before each tranformation matrix

syms d0 d1 d2 d3 d4 d5 d6
syms a b c d e f g

d0=0.1105;
d1=0.31048-0.1105;
d2=0.5105-0.31048;
d3=0.7105-0.5105;
d4=0.9105-0.7105;
d5=1.1005-0.9105;
d6=1.1785-1.1005;

A=screw_matrix1(0,0,1,0,0,d0)
B=screw_matrix2(0,-1,0,0,0,d0+d1)
C=screw_matrix3(0,0,1,0,0,d0+d1+d2)
D=screw_matrix4(0,-1,0,0,0,d0+d1+d2+d3)
E=screw_matrix5(0,0,1,0,0,d0+d1+d2+d3+d4)
F=screw_matrix6(0,-1,0,0,0,d0+d1+d2+d3+d4+d5)
G=screw_matrix7(0,0,1,0,0,d0+d1+d2+d3+d4+d5+d6)

Ah = A*B*C*D*E*F*G;



P= [1      0         0        0;
      0      1         0      0;
      0      0         1     d0+d1+d2+d3+d4+d5+d6;
      0      0         0      1]



FK = Ah*P

%solution in close loop form (general form in thetas)
%---------------------------------------------------------------

function M = screw_matrix1(Sx, Sy, Sz, Sox, Soy, Soz)

syms t1 t;
t1 = -pi/2; 
t=0;

a11 = (Sx^2 - 1)*(1 - cos(t1)) + 1;
a12 = Sx*Sy*(1 - cos(t1)) - Sz*sin(t1);
a13 = Sx*Sz*(1 - cos(t1)) + Sy*sin(t1);
a21 = Sy*Sx*(1 - cos(t1)) + Sz*sin(t1);
a22 = (Sy^2 - 1)*(1 - cos(t1)) + 1;
a23 = Sy*Sz*(1 - cos(t1)) - Sx*sin(t1);
a31 = Sz*Sx*(1 - cos(t1)) - Sy*sin(t1);
a32 = Sz*Sy*(1 - cos(t1)) + Sx*sin(t1);
a33 = (Sz^2 - 1)*(1 - cos(t1)) + 1;

a14 = t*Sx - Sox*(a11 - 1) - Soy*a12 - Soz*a13;
a24 = t*Sy - Sox*a21 - Soy*(a22 - 1) - Soz*a23;
a34 = t*Sz - Sox*a31 - Soy*a32 - Soz*(a33 - 1);

M = [a11 a12 a13 a14; 
    a21 a22 a23 a24; 
    a31 a32 a33 a34; 
    0 0 0 1];

end

function N = screw_matrix2(Sx, Sy, Sz, Sox, Soy, Soz)

syms t2 t;
t2 = pi/2; 
t=0;

a11 = (Sx^2 - 1)*(1 - cos(t2)) + 1;
a12 = Sx*Sy*(1 - cos(t2)) - Sz*sin(t2);
a13 = Sx*Sz*(1 - cos(t2)) + Sy*sin(t2);
a21 = Sy*Sx*(1 - cos(t2)) + Sz*sin(t2);
a22 = (Sy^2 - 1)*(1 - cos(t2)) + 1;
a23 = Sy*Sz*(1 - cos(t2)) - Sx*sin(t2);
a31 = Sz*Sx*(1 - cos(t2)) - Sy*sin(t2);
a32 = Sz*Sy*(1 - cos(t2)) + Sx*sin(t2);
a33 = (Sz^2 - 1)*(1 - cos(t2)) + 1;

a14 = t*Sx - Sox*(a11 - 1) - Soy*a12 - Soz*a13;
a24 = t*Sy - Sox*a21 - Soy*(a22 - 1) - Soz*a23;
a34 = t*Sz - Sox*a31 - Soy*a32 - Soz*(a33 - 1);

N = [a11 a12 a13 a14; 
    a21 a22 a23 a24; 
    a31 a32 a33 a34; 
    0 0 0 1];

end

function O = screw_matrix3(Sx, Sy, Sz, Sox, Soy, Soz)

syms t3 t;
t3 = -pi/2; 
t=0;

a11 = (Sx^2 - 1)*(1 - cos(t3)) + 1;
a12 = Sx*Sy*(1 - cos(t3)) - Sz*sin(t3);
a13 = Sx*Sz*(1 - cos(t3)) + Sy*sin(t3);
a21 = Sy*Sx*(1 - cos(t3)) + Sz*sin(t3);
a22 = (Sy^2 - 1)*(1 - cos(t3)) + 1;
a23 = Sy*Sz*(1 - cos(t3)) - Sx*sin(t3);
a31 = Sz*Sx*(1 - cos(t3)) - Sy*sin(t3);
a32 = Sz*Sy*(1 - cos(t3)) + Sx*sin(t3);
a33 = (Sz^2 - 1)*(1 - cos(t3)) + 1;

a14 = t*Sx - Sox*(a11 - 1) - Soy*a12 - Soz*a13;
a24 = t*Sy - Sox*a21 - Soy*(a22 - 1) - Soz*a23;
a34 = t*Sz - Sox*a31 - Soy*a32 - Soz*(a33 - 1);

O = [a11 a12 a13 a14; 
    a21 a22 a23 a24; 
    a31 a32 a33 a34; 
    0 0 0 1];

end

function P = screw_matrix4(Sx, Sy, Sz, Sox, Soy, Soz)

syms t4 t;
t4 = pi/2; 
t=0;

a11 = (Sx^2 - 1)*(1 - cos(t4)) + 1;
a12 = Sx*Sy*(1 - cos(t4)) - Sz*sin(t4);
a13 = Sx*Sz*(1 - cos(t4)) + Sy*sin(t4);
a21 = Sy*Sx*(1 - cos(t4)) + Sz*sin(t4);
a22 = (Sy^2 - 1)*(1 - cos(t4)) + 1;
a23 = Sy*Sz*(1 - cos(t4)) - Sx*sin(t4);
a31 = Sz*Sx*(1 - cos(t4)) - Sy*sin(t4);
a32 = Sz*Sy*(1 - cos(t4)) + Sx*sin(t4);
a33 = (Sz^2 - 1)*(1 - cos(t4)) + 1;

a14 = t*Sx - Sox*(a11 - 1) - Soy*a12 - Soz*a13;
a24 = t*Sy - Sox*a21 - Soy*(a22 - 1) - Soz*a23;
a34 = t*Sz - Sox*a31 - Soy*a32 - Soz*(a33 - 1);

P = [a11 a12 a13 a14; 
    a21 a22 a23 a24; 
    a31 a32 a33 a34; 
    0 0 0 1];

end

function Q = screw_matrix5(Sx, Sy, Sz, Sox, Soy, Soz)

syms t5 t;
t5 = -pi/2; 
t=0;

a11 = (Sx^2 - 1)*(1 - cos(t5)) + 1;
a12 = Sx*Sy*(1 - cos(t5)) - Sz*sin(t5);
a13 = Sx*Sz*(1 - cos(t5)) + Sy*sin(t5);
a21 = Sy*Sx*(1 - cos(t5)) + Sz*sin(t5);
a22 = (Sy^2 - 1)*(1 - cos(t5)) + 1;
a23 = Sy*Sz*(1 - cos(t5)) - Sx*sin(t5);
a31 = Sz*Sx*(1 - cos(t5)) - Sy*sin(t5);
a32 = Sz*Sy*(1 - cos(t5)) + Sx*sin(t5);
a33 = (Sz^2 - 1)*(1 - cos(t5)) + 1;

a14 = t*Sx - Sox*(a11 - 1) - Soy*a12 - Soz*a13;
a24 = t*Sy - Sox*a21 - Soy*(a22 - 1) - Soz*a23;
a34 = t*Sz - Sox*a31 - Soy*a32 - Soz*(a33 - 1);

Q = [a11 a12 a13 a14; 
    a21 a22 a23 a24; 
    a31 a32 a33 a34; 
    0 0 0 1];

end

function R = screw_matrix6(Sx, Sy, Sz, Sox, Soy, Soz)

syms t6 t;
t6 = pi/2; 
t=0;

a11 = (Sx^2 - 1)*(1 - cos(t6)) + 1;
a12 = Sx*Sy*(1 - cos(t6)) - Sz*sin(t6);
a13 = Sx*Sz*(1 - cos(t6)) + Sy*sin(t6);
a21 = Sy*Sx*(1 - cos(t6)) + Sz*sin(t6);
a22 = (Sy^2 - 1)*(1 - cos(t6)) + 1;
a23 = Sy*Sz*(1 - cos(t6)) - Sx*sin(t6);
a31 = Sz*Sx*(1 - cos(t6)) - Sy*sin(t6);
a32 = Sz*Sy*(1 - cos(t6)) + Sx*sin(t6);
a33 = (Sz^2 - 1)*(1 - cos(t6)) + 1;

a14 = t*Sx - Sox*(a11 - 1) - Soy*a12 - Soz*a13;
a24 = t*Sy - Sox*a21 - Soy*(a22 - 1) - Soz*a23;
a34 = t*Sz - Sox*a31 - Soy*a32 - Soz*(a33 - 1);

R = [a11 a12 a13 a14; 
    a21 a22 a23 a24; 
    a31 a32 a33 a34; 
    0 0 0 1];

end

function S = screw_matrix7(Sx, Sy, Sz, Sox, Soy, Soz)

syms t7 t;
t7 = 0; 
t=0;

a11 = (Sx^2 - 1)*(1 - cos(t7)) + 1;
a12 = Sx*Sy*(1 - cos(t7)) - Sz*sin(t7);
a13 = Sx*Sz*(1 - cos(t7)) + Sy*sin(t7);
a21 = Sy*Sx*(1 - cos(t7)) + Sz*sin(t7);
a22 = (Sy^2 - 1)*(1 - cos(t7)) + 1;
a23 = Sy*Sz*(1 - cos(t7)) - Sx*sin(t7);
a31 = Sz*Sx*(1 - cos(t7)) - Sy*sin(t7);
a32 = Sz*Sy*(1 - cos(t7)) + Sx*sin(t7);
a33 = (Sz^2 - 1)*(1 - cos(t7)) + 1;

a14 = t*Sx - Sox*(a11 - 1) - Soy*a12 - Soz*a13;
a24 = t*Sy - Sox*a21 - Soy*(a22 - 1) - Soz*a23;
a34 = t*Sz - Sox*a31 - Soy*a32 - Soz*(a33 - 1);

S = [a11 a12 a13 a14; 
    a21 a22 a23 a24; 
    a31 a32 a33 a34; 
    0 0 0 1];

end