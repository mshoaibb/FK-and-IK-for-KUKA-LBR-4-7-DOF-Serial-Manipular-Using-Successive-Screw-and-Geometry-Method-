function Kuka4_show()

    syms q1 q2 q3 q4 q5 q6 q7 

    q = [0 0 0 0 0 0 0];

    % Link lengths in meter
    % for KUKA LWR 4+
    
    d0 = 0.1105;
    d1 = 0.2;
    d2 = 0.2;
    d3 = 0.2;
    d4 = 0.2;
    d5 = 0.19;
    d6 = 0.0780;

    L(1) = Link([0 d0 0 -pi/2]);
    L(2) = Link([0 d1 0 pi/2]);
    L(3) = Link([0 d2 0 -pi/2]);
    L(4) = Link([0 d3 0 pi/2]);
    L(5) = Link([0 d4 0 -pi/2]);
    L(6) = Link([0 d5 0 pi/2]);
    L(7) = Link([0 d6 0 0]);

    Kuka4 = SerialLink(L, 'name', 'kuka LWR 4+');

    figure(1);
    Kuka4.plot(q);

  end

